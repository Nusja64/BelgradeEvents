package com.android.belgradeevents;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.w3c.dom.Text;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.TextView;

public class ZoomImageActivity extends Activity {
	
	ImageView imageView;
	TextView textView;
	Bitmap bitmap;
	URL newurl;
	
	String comm ="";
	String url="";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.zoom_image);
		
		init();
		setData();
	}

	private void setData() {
		// TODO Auto-generated method stub
		
		textView.setText(comm);
		
		Thread thread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					newurl = new URL(url);
					
					bitmap = BitmapFactory.decodeStream(newurl.openConnection() .getInputStream());
					
					runOnUiThread(new Runnable() {
						
								        @Override
								        public void run() {
								        	
								        	imageView.setImageBitmap(bitmap);;
								        	
								        }
								    });
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}) ;
		
			thread.start();

		
	}

	private void init() {
		// TODO Auto-generated method stub
		
		comm = getIntent().getExtras().getString("comment");
		url = getIntent().getExtras().getString("image");
		
		imageView = (ImageView) findViewById(R.id.imageViewZoom);
		textView = (TextView) findViewById(R.id.txtComment);
		
	}

}
