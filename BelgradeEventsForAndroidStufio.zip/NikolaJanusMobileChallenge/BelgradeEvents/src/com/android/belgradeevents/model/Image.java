package com.android.belgradeevents.model;

public class Image {

	private String imageUrl;
	private String comment;
	
	public Image() {
		super();
	
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
}
