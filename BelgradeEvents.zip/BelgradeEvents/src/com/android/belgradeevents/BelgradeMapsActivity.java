package com.android.belgradeevents;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.zip.Inflater;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.support.v4.app.FragmentActivity;
import android.support.v4.media.session.PlaybackStateCompat.CustomAction;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.Gravity;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.annotation.SuppressLint;
import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;


import com.android.belgradeevents.model.Event;
import com.android.belgradeevents.model.Image;
import com.android.belgradeevents.model.Location;
import com.google.android.gms.internal.mz;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnMapLoadedCallback;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;

import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;




public class BelgradeMapsActivity extends Activity{
	
	private final static LatLng LOCATION_BELGRADE = new LatLng(44.8180937,20.4431559);
	public final static String tag = "error";
	
	
	private GoogleMap map;

	private NetworkClass nc = new NetworkClass(this);
	private BrokerSQLite db = new BrokerSQLite(this);
	private HashMap<MarkerOptions, Event> eventMarkerMap;
	
	//public static int EventIDClicked = 0;
	
	ArrayList<Image> images;
	LinearLayout myGallery;
	
	
	
	

	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        
        	initMap();
        	//setMarkers();
        	if (isOnline())
			{
        		
        		new AsyncGetData().execute();
			}
			else
			{
				Toast.makeText(BelgradeMapsActivity.this, "NO NETWORK. Can not show markers".toUpperCase(), Toast.LENGTH_LONG)
						.show();
			}
        
        
      
        }

	private void setMarkers(ArrayList<Event> events) {
		
		Event event;
		
		for (int i = 0; i < events.size(); i++) {

			event = new Event();
			event = events.get(i);
			MarkerOptions customMarker = new MarkerOptions();
			
			eventMarkerMap = new HashMap<MarkerOptions, Event>();
		
		// TODO Auto-generated method stub
		///check and set tags	
			String tags="";
		
			if (event.getTags().size() >= 1) {
			    tags = event.getTags().get(0);
			}
	
			for (String element : event.getTags()) {
				
				if (!element.equalsIgnoreCase(tags))
					tags += ", " +element;
				
			}
		
		//cneck date	
		String endDate = "";
		if (event.getEnding_at().isEmpty() || event.getEnding_at().equalsIgnoreCase("null") || event.getEnding_at().equalsIgnoreCase("TIMESTAMP"))
			endDate="/";
		else endDate = event.getEnding_at().substring(0, 10);
		
		String startDate = "";
		if (event.getStarting_at().isEmpty() || event.getStarting_at().equalsIgnoreCase("null") || event.getStarting_at().equalsIgnoreCase("TIMESTAMP"))
			startDate="/";
		else startDate = event.getStarting_at().substring(0, 10);
	
		
		//set color of marker	
		
		float hue = 0f;
		
		if (event.Is_trending()==1)
		{
			hue =  (float) BitmapDescriptorFactory.HUE_YELLOW;
		}
		else
		{
			hue =  (float) BitmapDescriptorFactory.HUE_GREEN;
		}
	
		
		
	    customMarker = new MarkerOptions().position(new LatLng(event.getLocation().getLat(),event.getLocation().getLng())).
		snippet("Start date : "+startDate+"\n"+"End date : "+endDate+"\n"+"Tag : "+tags).
		icon(BitmapDescriptorFactory.defaultMarker(hue)).
		title(event.getName());
	    
	    
	    map.addMarker(customMarker);
	    
	    eventMarkerMap.put(customMarker, event);
	    
	 //   Event eve = eventMarkerMap.get(customMarker);
	    
	//    EventIDClicked = eve.getEventID();
	
    // moveToCurrentLocation(customMarker.getPosition());
     
     map.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {

         @Override
         public View getInfoWindow(Marker arg0) {
             return null;
         }

         @Override
         public View getInfoContents(Marker marker) {

             Context context = getApplicationContext(); //or getActivity(), YourActivity.this, etc.

             LinearLayout info = new LinearLayout(context);
             info.setOrientation(LinearLayout.VERTICAL);

             TextView title = new TextView(context);
             title.setTextColor(Color.BLACK);
             title.setGravity(Gravity.CENTER);
             title.setTypeface(null, Typeface.BOLD);
             title.setText(marker.getTitle());

             TextView snippet = new TextView(context);
             snippet.setTextColor(Color.GRAY);
             snippet.setText(marker.getSnippet());

             info.addView(title);
             info.addView(snippet);

             return info;
         }
     });
     
     
     setMarkerListener(customMarker);
	

		}	
	}


	private void moveToCurrentLocation(LatLng currentLocation)
	{   
	   
		//  map.animateCamera(CameraUpdateFactory.zoomTo(17), 4000, null);
			CameraUpdate update = CameraUpdateFactory.newLatLngZoom(currentLocation, 16.25f);
	        map.moveCamera(update);


	}

	private void setMarkerListener(MarkerOptions marker) {
		// TODO Auto-generated method stuerb
		  
		

		map.setOnMarkerClickListener(new OnMarkerClickListener() {
		
		@Override
		public boolean onMarkerClick(Marker arg0) {
			// TODO Auto-generated method stub
			
		moveToCurrentLocation(arg0.getPosition());
	//	Event eventInfo = eventMarkerMap.get(marker);
		
			
			return false;
		}
	})	;
		
	
	map.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {
		         @Override
		         public void onInfoWindowClick(Marker marker) {
		          
		        	 //Toast.makeText(BelgradeMapsActivity.this, "Testirnje klika", Toast.LENGTH_SHORT).show();
		        	 if (isOnline())
		 			{
		         		
		        		// Event eventInfo = eventMarkerMap.get(marker);
		        		AsyncGetPicture getPicture = new AsyncGetPicture();
		         		getPicture.lat = marker.getPosition().latitude;
		         		getPicture.lng = marker.getPosition().longitude;
		         	//	getPicture.eventID = EventIDClicked;
		         		getPicture.execute();
		         	//	map.addMarker(marker.setIcon(BitmapDescriptorFactory.defaultMarker( BitmapDescriptorFactory.HUE_CYAN)));
		 			}
		 			else
		 			{
		 				Toast.makeText(BelgradeMapsActivity.this, "NO NETWORK. Can not show markers".toUpperCase(), Toast.LENGTH_LONG)
		 						.show();
		 			}

		         }
		     });
			  
		 
				 
				
			
		
	}

	private void initMap() {
		// TODO Auto-generated method stub
    	map = ((MapFragment)  getFragmentManager().findFragmentById(R.id.fragmentMap)).getMap();
        map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(LOCATION_BELGRADE, 11.25f);
        map.animateCamera(update);
        map.setMyLocationEnabled(true);
		
	}

	@SuppressLint("NewApi") private class AsyncGetPicture extends AsyncTask<Void, Void, Void> {
		
		JSONArray resJsonArrayPicture;
		 URL newurl;
         Bitmap bitmap;
		
		double lng;
		double lat;
		int eventID;
		boolean IsOK = false;
		Dialog statusDialogPicture = new Dialog(BelgradeMapsActivity.this);

		@Override
		protected void onPreExecute()
		{
			
			BelgradeMapsActivity.this.runOnUiThread(new Runnable() {

				@Override
				public void run()
				{
					statusDialogPicture.setTitle(getString(R.string.fetchingDatafromServerImg));
					statusDialogPicture.setContentView(R.layout.circular_progress_bar);
					statusDialogPicture.show();
				}
			});

			super.onPreExecute();
		}
		
		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			try {
				
				db.open();
				eventID = db.getEventID(lng,lat);
				resJsonArrayPicture = nc.searchRequestForImages(eventID);
				
				IsOK= parseJsonForImages(resJsonArrayPicture);
			//	if(resJsonArrayPicture.equals(null)||resJsonArrayPicture.isNull(0))
				//	IsOK = false;
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return null;
		}
		
		private boolean parseJsonForImages(JSONArray jsonArray) {
			
			images = new ArrayList<Image>();
			try
			{
				if (jsonArray == null || jsonArray.toString().equalsIgnoreCase("null"))
				{
					return false;
				}
				
				else
				{
					
					for (int i = 0; i < jsonArray.length(); i++)
					{
						
						Image image = new Image();

						JSONObject obj = jsonArray.getJSONObject(i);
						
						image.setImageUrl(obj.getString("image"));
						image.setComment(obj.getString("description"));
						images.add(image);
						//Log.i(urlImages, "testing");
						
											
						
	
					}

				}
			}
			catch (Exception e)
			{
				Log.e(tag, "Error witjh parsing JSOn to model class!", e);
				return false;
			}
			return true;

		}

//	public	View setView(Bitmap bitmap)
//	{
//		    
//
//		 	LinearLayout layout =  new LinearLayout(getApplicationContext());
//		 	layout.setLayoutParams(new LayoutParams(250, 250));
//		 	layout.setGravity(Gravity.CENTER);
//
//		     ImageView imageView = new ImageView(getApplicationContext());
//		     imageView.setLayoutParams(new LayoutParams(220, 220));
//		     imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
//		     imageView.setImageBitmap(bitmap);
//
//		     layout.addView(imageView);
//		     return layout;
//		    
//	}	
	
		@SuppressLint({ "ShowToast", "NewApi" }) @Override
		protected void onPostExecute(Void result)
		{
			statusDialogPicture.cancel();
			if(IsOK)
			{
				HorizontalScrollView cvImages= (HorizontalScrollView) findViewById(R.id.hcvImages);
				cvImages.setVisibility(View.VISIBLE);
				
	            
				FrameLayout.LayoutParams HParams = new FrameLayout.LayoutParams(
		                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		       
		        cvImages.setLayoutParams(HParams);
		    
	           
	         
	         
	            
	             for (final Image image : images) {
	            	 
	            	 
	            	 Thread thread = new Thread(new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							try {
									newurl = new URL(image.getImageUrl());
									bitmap = BitmapFactory.decodeStream(newurl.openConnection() .getInputStream());
									myGallery = (LinearLayout) findViewById(R.id.llMyGallery);
					             
									
					    		 
									final ImageView btnTag = new ImageView(BelgradeMapsActivity.this);
									
									LayoutParams params = new LayoutParams(
											(int) getResources().getDimension(R.dimen.imageview_height),     
											(int) getResources().getDimension(R.dimen.imageview_height)
									);
									
									params.setMargins((int) getResources().getDimension(R.dimen.margins), (int) getResources().getDimension(R.dimen.margins), (int) getResources().getDimension(R.dimen.margins), (int) getResources().getDimension(R.dimen.margins));
									btnTag.setLayoutParams(params);
									btnTag.setScaleType(ImageView.ScaleType.CENTER_CROP);
									btnTag.setImageBitmap(bitmap);
									
									
									runOnUiThread(new Runnable() {

				                        @Override
				                        public void run() {
				                        	
				                        //	myGallery.clearFocus();
				                        	myGallery.setGravity(Gravity.BOTTOM);
				                        	myGallery.addView(btnTag); 
				                     //   	btnTag.destroyDrawingCache();
				                        	
				                        	
				                        
				                        	
				                        }
				                    });
									
									btnTag.setOnClickListener(new View.OnClickListener() {
										
										@Override
										public void onClick(View v) {
											// TODO Auto-generated method stub
//											db.open();
//											Location  loc = db.selectLocation(eventID);
//											MarkerOptions customMarker = new MarkerOptions().position(new LatLng(loc.getLat(),loc.getLng())).
//													
//													icon(BitmapDescriptorFactory.defaultMarker( BitmapDescriptorFactory.HUE_CYAN));
//													map.addMarker(customMarker);
											
											Intent zoom = new Intent(BelgradeMapsActivity.this, ZoomImageActivity.class);
											zoom.putExtra("comment",image.getComment());
											zoom.putExtra("image",image.getImageUrl().toString());
											startActivity(zoom);
											
											
											
										}
									});
			
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
						}
					}) ;
	            	 
					thread.start(); 
	 	             
    	
					
				}

			}
			else 
			{
				Toast.makeText(BelgradeMapsActivity.this,"There are no images!".toUpperCase(), Toast.LENGTH_LONG).show();
			}
		
			super.onPostExecute(result);
		}
		
	}
	

	private class AsyncGetData extends AsyncTask<Void, Void, Void> {
		
		JSONArray resJsonArray;
		
		boolean IsOK = false;
		Dialog statusDialog = new Dialog(BelgradeMapsActivity.this);

		@Override
		protected void onPreExecute()
		{
			BelgradeMapsActivity.this.runOnUiThread(new Runnable() {

				@Override
				public void run()
				{
					statusDialog.setTitle(getString(R.string.fetchingDatafromServer));
					statusDialog.setContentView(R.layout.circular_progress_bar);
					statusDialog.show();
				}
			});

			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(Void... params)
		{
			try
			{
				resJsonArray = nc.searchRequest();
				IsOK = parseJsonToModle(resJsonArray);
				
			
				
				
				
			}
			catch (Exception e)
			{
				Log.e("error", "error", e);
				
			}
			return null;
		}

		
		private boolean parseJsonToModle(JSONArray jsArray) {
			
			
			try
			{
				if (jsArray == null || jsArray.toString().equalsIgnoreCase("null"))
				{
					return false;
				}
				
				else
				{
					Event event; 
					Location location;
					for (int i = 0; i < jsArray.length(); i++)
					{
						int isTre = 0;
						event = new Event();
						location = new Location();

						JSONObject obj = jsArray.getJSONObject(i);
						
						event.setEventID(obj.getInt("id"));
						event.setName(obj.getString("name"));
						event.setStarting_at(obj.getString("starting_at"));
						event.setEnding_at(obj.getString("ending_at"));
						isTre = obj.getBoolean("is_trending")? 1 : 0;
						event.setIs_trending(isTre);	
						JSONObject jsonLocation = obj.getJSONObject("location");
						location.setLat(jsonLocation.getDouble("lat"));
						location.setLng(jsonLocation.getDouble("lng"));
						event.setLocation(location);
						ArrayList<String> tags = new ArrayList<String>();
						
						
						JSONArray jsArrayTags = obj.getJSONArray("tags");
						//String tag="";
						for (int j = 0; j < jsArrayTags.length(); j++)
						{
							String tag="";
							tag = (String) jsArrayTags.get(j);
							tags.add(tag);
						}
						
						event.setTags(tags);
						
						insertDataInDB(event);
						
						
	
					}

				}
			}
			catch (Exception e)
			{
				Log.e(tag, "Error witjh parsing JSOn to model class!", e);
				return false;
			}
			return true;

		}


		private void insertDataInDB(Event event) {
			// TODO Auto-generated method stub
			db.open();
			try {
				db.Delete_Event(event);
				db.Event_I(event);
				db.Location_I(event);
				//db.Tag_I_U(event);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}

		@SuppressLint("ShowToast") @Override
		protected void onPostExecute(Void result)
		{
			statusDialog.cancel();
			if(IsOK)
			{
				db.open();
				ArrayList<Event> events = new ArrayList<Event>();
				try {
					events = db.select_event();
					if (events.size()==0)
							{
								///nlist is empty	
							}
					else
					{
						setMarkers(events);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					Log.e(tag,"Error set select event from db", e);
				}
				
				
			}
			else 
			{
				Toast.makeText(BelgradeMapsActivity.this,"Something wrong!Can not load google events and markers!".toUpperCase(), Toast.LENGTH_SHORT).show();
			}
		
			super.onPostExecute(result);
		}
	}

	protected boolean isOnline()
	{
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		if (netInfo != null && netInfo.isConnected())
		{
			return true;
		}
		else
		{
			Log.d("tag", "No network available!");
			return false;
		}
	}


	

   
}
